<?php

return [
    'adminEmail' => 'test.th.welcome@gmail.com',
];
